#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recorda que has de fer la "entrega_01" usant un Rproject
#- contesta les preguntes en aquest script.
#- no esborris els enunciats de les preguntes
#- utilitza les IA's amb moderació; millor parla amb els teus companys/es, fins i tot amb Google
#- Si tens algun dubte, no dubtis a preguntar
#- Intenta fer-ho tot, però no m'aclaparis (molt) si no et surt tot, recorda que estem aprenent
#-------------------------------------------------------------------------------




#- TASCA 01: ------
#- En aquesta adreça hi ha unes dades: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarrega aquest fitxer de dades i guarda'l a la subcarpeta "datos"

my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

fs::dir_create("datos")

download.file(my_url, "./datos/pob_mundi_1996_2020.rda")

#- TASCA 02: ------
#- importa les dades que acabes de descarregar al Global Env. 
#- Pots fer-ho amb el pkg "rio". Truca a l'objecte "df"
#- En quin format estan ara les dades?

typeof(my_ruta)

str(my_ruta)

my_ruta <- "./datos/pob_mundi_1996_2020.rda"

df <- rio::import(file = my_ruta)


#- En quin format estan les dades?

typeof(df)

str(df)

#- TASCA 03: -------
#- Ara hauràs d'exportar 3 vegades les dades que hi ha a "df" 3. Sempre a la carpeta "datos".
#- 3.a)  exporta les dades a format. xlsx (recordeu-vos d'utilitzar rutes relatives)

rio::export(x = df,
            file = "./datos/pob_mundi_1996_2020.xlsx")

#- 3.b) Exporta les dades a format .rds utilitzant ruta relativa

rio::export(x = df,
            file = "./datos/pob_mundi_1996_2020.rds")


#- 3.c) Exporta'ls una altra vegada però ara a format .csv

rio::export(x = df,
            file = "./datos/pob_mundi_1996_2020.csv")



#- TASCA 04: -------
#- utilitza el pkg "eurostat" per descarregar unes dades q mitjà t'interessin.
#- Explica'm (usant comentaris) quines dades t'has descarregat i quines variables tens

install.packages("eurostat")

library(eurostat)
#Buscamos unos datos por la base de datos de Eurostat y miramos el código que tiene esa tabla de datos.
#importamos los datos de la tabla "ext_stec03": "Comercio de servicios por características de la empresa (STEC) por actividades de NACE Rev.2 y tipo de propiedad"

df <- eurostat::get_eurostat("ext_stec03")


#Me he descargado una tabla que representa el comercio de servicios por características de la empresa (STEC) se refiere a la recopilación de datos estadísticos que analizan las transacciones de servicios entre países, segmentadas según características específicas de las empresas que participan. Estas características incluyen el tamaño de la empresa, la actividad económica (usando la clasificación NACE Rev.2), y el tipo de propiedad de la empresa (por ejemplo, empresas nacionales o extranjeras).

#En la tabla aparecen 9 variables:
#freq: Probablemente representa la frecuencia de los datos (por ejemplo, anual).
#unit: La unidad de medida (en este caso parece ser "THS_EUR", miles de euros).
#enterpr: Tipo de empresa (por ejemplo, DOMC, que probablemente se refiere a empresas domésticas).
#stk_flow: Flujo económico o tipo de comercio (por ejemplo, exportaciones EXP).
#nace_r2: Código de actividad económica según la clasificación NACE Rev.2.
#partner: Socio comercial o área geográfica involucrada en el comercio.
#geo: Código geográfico o país que participa en el comercio.
#TIME_PERIOD: Años (de 2013 a 2022 en este caso).
#values: se refiere a los datos numéricos que representan el comercio de servicios para cada combinación de características.