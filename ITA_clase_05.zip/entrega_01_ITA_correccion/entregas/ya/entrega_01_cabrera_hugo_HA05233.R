# TAREA 01: Descargar fichero de datos
if(!dir.exists("datos")) dir.create("datos")
download.file(
  url = "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda",
  destfile = "datos/pob_muni_1996_2020.rda"
)

# TAREA 02: Importar los datos al entorno global con 'rio'
if(!require(rio)) install.packages("rio")
library(rio)
df <- import("datos/pob_muni_1996_2020.rda")
str(df)

# TAREA 03: Exportar los datos a diferentes formatos
export(df, "datos/pob_muni_1996_2020.xlsx")  # 3.a
export(df, "datos/pob_muni_1996_2020.rds")   # 3.b
export(df, "datos/pob_muni_1996_2020.csv")   # 3.c

# TAREA 04: Descargar datos con 'eurostat'
if(!require(eurostat)) install.packages("eurostat")
library(eurostat)
population_data <- get_eurostat("demo_r_pjangroup")
head(population_data)