#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recuerda que has de hacer la "entrega_01" usando un Rproject
#- contesta a las preguntas en este script.
#- no borres los enunciados de las preguntas
#- usa las IA's con moderación; mejor habla con tus compañeras/os, incluso con Google
#- Si tienes alguna duda, no dudes en preguntar
#- Intenta hacerlo todo, pero no me agobies (mucho) si no te sale todo, recuerda que estamos aprendiendo
#-------------------------------------------------------------------------------




#- TAREA 01: ------
#- En esta dirección hay unos datos: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarga ese fichero de datos y guárdalo en la subcarpeta "datos"


my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

fs::dir_create("datos")

download.file(my_url, "./datos.rda")

download.file(url = my_url,
              destfile = "./datos.rda")


#- TAREA 02: ------
#- importa los datos que acabas de descargar al Global Env. 
#- Puedes hacerlo con el pkg "rio". Llama al objeto "df"
#- ¿En que formato están ahora los datos?

my_ruta <- "./datos.rda"

df <- rio::import(my_ruta)


#- ¿En qué formato están los datos?

#En el formato data frame.


#- TAREA 03: -------
#- Ahora tendrás que exportar 3 veces los datos que hay en "df" 3. Siempre en la carpeta "datos".
#- 3.a)  exporta los datos a formato . xlsx  (acuerdate de utilizar rutas relativas)

rio::export(df, "./datos/my_ruta.xlsx")

#- 3.b) Exporta los datos a formato .rds utilizando ruta relativa

rio::export(df, "./datos/my_ruta.rds")


#- 3.c) Expórtalos otra vez pero ahora en formato .csv

rio::export(df, "./datos/my_ruta.csv")


#- TAREA 04: -------
#- utiliza el pkg "eurostat" para descargar unos datos q medio te interesen.
#- Cuéntame (usando comentarios) que datos te has descargado y que variables tienes
#Los datos que me he descargado corresponden con las personas empleadas con mas de 15 años, separado por sexo, nacionalidad y economia.
library(eurostat)

aa <- search_eurostat("employment", type = "all") 

my_table <- "cens_01ractz"  


df <- get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )   


