#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recuerda que has de hacer la "entrega_01" usando un Rproject
#- contesta a las preguntas en este script.
#- no borres los enunciados de las preguntas
#- usa las IA's con moderación; mejor habla con tus compañeras/os, incluso con Google
#- Si tienes alguna duda, no dudes en preguntar
#- Intenta hacerlo todo, pero no me agobies (mucho) si no te sale todo, recuerda que estamos aprendiendo
#-------------------------------------------------------------------------------




#- TAREA 01: ------
#- En esta dirección hay unos datos: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarga ese fichero de datos y guárdalo en la subcarpeta "datos"

mi_url <-"https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"
fs::dir_create("datos")
download.file(mi_url,"./datos/datos_tarea.rda")
download.file(url = mi_url,
              destfile = "./datos/datos_tarea.rda")
#- TAREA 02: ------
#- importa los datos que acabas de descargar al Global Env. 
#- Puedes hacerlo con el pkg "rio". Llama al objeto "df"
#- ¿En que formato están ahora los datos?

install.packages("palmerpenguins")
install.packages("rio")
library(rio)
library(palmerpenguins)

mis_chimuelos <- penguins

mi_ruta <- "./datos/datos_tarea.rda"

df <- rio::import(mi_ruta)


#- ¿En qué formato están los datos?

"Los datos estan en formato data.frame"


#- TAREA 03: -------
#- Ahora tendrás que exportar 3 veces los datos que hay en "df" 3. Siempre en la carpeta "datos".
#- 3.a)  exporta los datos a formato . xlsx  (acuerdate de utilizar rutas relativas)

rio::export(df,"./datos/chimuelo.xlsx")


#- 3.b) Exporta los datos a formato .rds utilizando ruta relativa

rio::export(df,"./datos/chimuelo2.0.rds")


#- 3.c) Expórtalos otra vez pero ahora en formato .csv

rio::export(df,"./datos/chimuelo3.0.csv")



#- TAREA 04: -------
#- utiliza el pkg "eurostat" para descargar unos datos q medio te interesen.
#- Cuéntame (usando comentarios) que datos te has descargado y que variables tienes

install.packages("eurostat")
library(eurostat)

df <- eurostat::get_eurostat("cult_emp_sex")

aa <- eurostat::ea_countries

bb <- get_eurostat(my_table)
rio::export(aa,"./datos/paises.xlsx")

