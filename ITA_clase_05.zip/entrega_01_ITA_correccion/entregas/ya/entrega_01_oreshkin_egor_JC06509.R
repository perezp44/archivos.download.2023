#- TAREA 01: ------
#- En esta dirección hay unos datos: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarga ese fichero de datos y guárdalo en la subcarpeta "datos"

el_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"
dir.create("el_proyecto")
setwd("C:/Users/User/Documents/el_proyecto")
dir.create("datos")
download.file(el_url, "./datos/el_fichero.rda")


#- TAREA 02: ------
#- importa los datos que acabas de descargar al Global Env. 
#- Puedes hacerlo con el pkg "rio". Llama al objeto "df"
#- ¿En que formato están ahora los datos?

library(rio)
la_ruta <- "./datos/el_fichero.rda"
df <- rio::import("./datos/el_fichero.rda")

# En la carpeta era .rda, ahora es .df

#- ¿En qué formato están los datos?

# .df


#- TAREA 03: -------
#- Ahora tendrás que exportar 3 veces los datos que hay en "df" 3. Siempre en la carpeta "datos".
#- 3.a)  exporta los datos a formato . xlsx  (acuerdate de utilizar rutas relativas)

rio::export(df, "./datos/df.xlsx")


#- 3.b) Exporta los datos a formato .rds utilizando ruta relativa

rio::export(df, "./datos/df.rds")

#- 3.c) Expórtalos otra vez pero ahora en formato .csv

rio::export(df, "./datos/df.csv")


#- TAREA 04: -------
#- utiliza el pkg "eurostat" para descargar unos datos q medio te interesen.
#- Cuéntame (usando comentarios) que datos te has descargado y que variables tienes

library(eurostat)
cambio <- eurostat::get_eurostat("ert_bil_eur_a")
ingresos <- eurostat::get_eurostat("ilc_di02")
PIB <- eurostat::get_eurostat("tec00001")

#- He descargado 1)los datos de tipos de cambio de euro anualmente (el variable "cambio"),
#- 2)los ingresos de diferentes grupos (el variable "ingresos"), 3)y los valores de PIB de 
#- países por cada año