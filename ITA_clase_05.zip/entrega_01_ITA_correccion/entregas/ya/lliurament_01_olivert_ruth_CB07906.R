#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recorda que has de fer la "entrega_01" usant un Rproject
#- contesta les preguntes en aquest script.
#- no esborris els enunciats de les preguntes
#- utilitza les IA's amb moderació; millor parla amb els teus companys/es, fins i tot amb Google
#- Si tens algun dubte, no dubtis a preguntar
#- Intenta fer-ho tot, però no m'aclaparis (molt) si no et surt tot, recorda que estem aprenent
#-------------------------------------------------------------------------------




#- TASCA 01: ------
#- En aquesta adreça hi ha unes dades: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarrega aquest fitxer de dades i guarda'l a la subcarpeta "datos"

my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

fs::dir_create("datos")

download.file(my_url, "./datos/pob_muni_1996_2020.rda")

#- TASCA 02: ------
#- importa les dades que acabes de descarregar al Global Env. 
#- Pots fer-ho amb el pkg "rio". Truca a l'objecte "df"
#- En quin format estan ara les dades?

my_url <- "./datos/pob_muni_1996_2020.rda"

df <- rio::import(my_url)

#- En quin format estan les dades?

str("df")


#- TASCA 03: -------
#- Ara hauràs d'exportar 3 vegades les dades que hi ha a "df" 3. Sempre a la carpeta "datos".
#- 3.a)  exporta les dades a format. xlsx (recordeu-vos d'utilitzar rutes relatives)

df <- my_url

rio::export(x= df, 
            file = "./datos/pob_muni_1996_2020.xlsx")

#- 3.b) Exporta les dades a format .rds utilitzant ruta relativa

rio::export(df, "./datos/my_url.rds")

#- 3.c) Exporta'ls una altra vegada però ara a format .csv

rio::export(df, "./datos/my_url.csv")


#- TASCA 04: -------
#- utilitza el pkg "eurostat" per descarregar unes dades q mitjà t'interessin.
#- Explica'm (usant comentaris) quines dades t'has descarregat i quines variables tens

library(eurostat)

aa <- search_eurostat("education", type= "all")

my_table <- "cens_11aed_r2"

eurostat::label_eurostat_tables(my_table)

df <- get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )

df_1 <- eurostat::label_eurostat(df)

#- he descarregat les dades sobre la població per estats de l´activitat actual, el nivell educatiu i la regió.