#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recorda que has de fer la "entrega_01" usant un Rproject
#- contesta les preguntes en aquest script.
#- no esborris els enunciats de les preguntes
#- utilitza les IA's amb moderació; millor parla amb els teus companys/es, fins i tot amb Google
#- Si tens algun dubte, no dubtis a preguntar
#- Intenta fer-ho tot, però no m'aclaparis (molt) si no et surt tot, recorda que estem aprenent
#-------------------------------------------------------------------------------




#- TASCA 01: ------
#- En aquesta adreça hi ha unes dades: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarrega aquest fitxer de dades i guarda'l a la subcarpeta "datos"

my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

fs::dir_create("datos")

download.file(my_url, "./datos/datos01.rda" )


#- TASCA 02: ------
#- importa les dades que acabes de descarregar al Global Env. 
#- Pots fer-ho amb el pkg "rio". Truca a l'objecte "df"
#- En quin format estan ara les dades?

my_ruta <- "./datos/datos01.rda"

df <- rio::import(my_ruta)

#- En quin format estan les dades?

#Les dades ara s'han convertit en data frames


#- TASCA 03: -------
#- Ara hauràs d'exportar 3 vegades les dades que hi ha a "df" 3. Sempre a la carpeta "datos".
#- 3.a)  exporta les dades a format. xlsx (recordeu-vos d'utilitzar rutes relatives)

df 
rio::export(df,"./datos/3.xlsx")


#- 3.b) Exporta les dades a format .rds utilitzant ruta relativa

rio::export(df,"./datos/3.rds")


#- 3.c) Exporta'ls una altra vegada però ara a format .csv

rio::export(df,"./datos/3.csv")


#- TASCA 04: -------
#- utilitza el pkg "eurostat" per descarregar unes dades q mitjà t'interessin.
#- Explica'm (usant comentaris) quines dades t'has descarregat i quines variables tens

install.packages("eurostat")

library(eurostat)

aa <- search_eurostat("education", type = "all") #para buscar sobre el tema de educación, y en el glob environment nos dice ya que tiene 9 variables

#- elegimos una tabla, en mi caso elegiré: Population by current activity status, educational attainment level and NUTS 2 region
"cens_11aed_r2"

my_table <- "cens_11aed_r2"

#ahora el siguiente código da información sobre la Base de datos que estas buscando, es decir sobre el tema de la tabla que he elegido que es:  Population by current activity status, educational attainment level and NUTS 2 region

eurostat::label_eurostat_tables(my_table)

#descargamos los datos con get_eurostat()
df <- get_eurostat(my_table) 

#después me sale un mensaje en rojo con la dirección del archivo, y lo que hice fue copiar esa dirección e ir a google, despues de pegar la direccion en la búsqueda y buscar se me descargo el archivo en descargas


