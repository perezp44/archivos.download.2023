#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recorda que has de fer la "entrega_01" usant un Rproject
#- contesta les preguntes en aquest script.
#- no esborris els enunciats de les preguntes
#- utilitza les IA's amb moderació; millor parla amb els teus companys/es, fins i tot amb Google
#- Si tens algun dubte, no dubtis a preguntar
#- Intenta fer-ho tot, però no m'aclaparis (molt) si no et surt tot, recorda que estem aprenent
#-------------------------------------------------------------------------------




#- TASCA 01: ------
#- En aquesta adreça hi ha unes dades: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarrega aquest fitxer de dades i guarda'l a la subcarpeta "datos"

my_url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"
curl::curl_download(url = my_url, 
                    destfile =  "./entrega_01/datos")

#- TASCA 02: ------
#- importa les dades que acabes de descarregar al Global Env. 
#- Pots fer-ho amb el pkg "rio". Truca a l'objecte "df"
#- En quin format estan ara les dades?
my_ruta <- "./entrega_01/datos/pob_muni_1996_2020.rda"
df <- rio::import(my_ruta)


#- En quin format estan les dades?
str(df)
#Les dades estan en un data frame


#- TASCA 03: -------
#- Ara hauràs d'exportar 3 vegades les dades que hi ha a "df" 3. Sempre a la carpeta "datos".
#- 3.a)  exporta les dades a format. xlsx (recordeu-vos d'utilitzar rutes relatives)
rio::export(x = df, file = "./entrega_01/datos/pob_muni_1996_2020.xlsx")


#- 3.b) Exporta les dades a format .rds utilitzant ruta relativa
rio::export(x = df, file = "./entrega_01/datos/pob_muni_1996_2020.rds")


#- 3.c) Exporta'ls una altra vegada però ara a format .csv
rio::export(x = df, file = "./entrega_01/datos/pob_muni_1996_2020.csv")



#- TASCA 04: -------
#- utilitza el pkg "eurostat" per descarregar unes dades q mitjà t'interessin.
#- Explica'm (usant comentaris) quines dades t'has descarregat i quines variables tens
library(eurostat)
aa <- search_eurostat("employment", type = "all")
my_table <- "ei_lmhu_m"
df2 <- get_eurostat(my_table, time_format = "date", keepFlags = TRUE ) 
str(df2)
#m'he descarregat les dades de persones desempleades 
#Les variables són les següents:
#freq: freqüència de les dades ("M" per mensual).
#unit: Unitat de mesura ("THS_PER" per milers de persones).
#s_adj: Ajustament estacional ("NSA" significa que les dades no estan ajustades estacionalment).
#indic: Indicador d'ocupació o atur ("LM-UN-F-GT25" pot indicar el grup de dones majors de 25 anys).
#geo: Codi geogràfic del país o regió ("AT" per Àustria).
#flags: Indicador de possibles notes o advertiments sobre les dades (si les dades han estat estimades).
#TIME_PERIOD: El període de temps en format 'yyyy-mm'.
#values: Valors numèrics que representen el nombre de persones (en milers o segons la unitat especificada).
