#- TASCA 01: ------
#- En aquesta adreça hi ha unes dades: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarrega aquest fitxer de dades i guarda'l a la subcarpeta "datos"

#-- Primer de tot, li tenim que donar un nom a les dades que ens donen.
mi_direcció <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

#-- Després amb la funció que vegam baix anem a crear la carpeta 'datos', on emmagatzenarem les nostres dades.
fs::dir_create("datos")

#-- Per útim amb la funció 'download' anem a descarregar les dades i a colocar-les a la carpeta de 'datos'.
download.file(mi_direcció, "./datos/pob_muni_1996_2020.rda")





#- TASCA 02: ------
#- importa les dades que acabes de descarregar al Global Env. 
#- Pots fer-ho amb el pkg "rio". Truca a l'objecte "df"
#- En quin format estan ara les dades?

#-- Primer li fiquem nom a les dades.
my_rute <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

#-- Després amb la funció 'rio' exportem les dades al global, i a més, li fiquem el nom de 'df'.
df <- rio::import(my_rute)


#- En quin format estan les dades?

#-- Amb la funció 'typeof' i teclejant el nom de les nostres dades podem vore en quin format estan.
typeof("df")

#- TASCA 03: -------
#- Ara hauràs d'exportar 3 vegades les dades que hi ha a "df" 3. Sempre a la carpeta "datos".
#- 3.a)  exporta les dades a format. xlsx (recordeu-vos d'utilitzar rutes relatives)

df <- my_url

rio::export( x = df,
             file = "./datos/my_url.xlsx")


#- 3.b) Exporta les dades a format .rds utilitzant ruta relativa


rio::export( x = df,
             file = "./datos/my_url.rds")  


#- 3.c) Exporta'ls una altra vegada però ara a format .csv


rio::export( x = df,
             file = "./datos/my_url.csv")







#- TASCA 04: -------
#- utilitza el pkg "eurostat" per descarregar unes dades q mitjà t'interessin.
#- Explica'm (usant comentaris) quines dades t'has descarregat i quines variables tens

#-- Primer de tot, carguem el paquet de eurostat.
library(eurostat)

#-- Busquem informació amb el següent codigo insertant el tema que volguem.
aa <- search_eurostat("migration", type = "all") 

#- elegim una taula de eurostat
#- "tps00176": "Immigration"
my_table <- "tps00176"  

#- aquest codigo ens donara informació sobre la taula que hem elegit.
label_eurostat_tables(my_table) 

#-  descarreguem les dades amb el codigo get_eurostat
df <- get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )   

    

   










