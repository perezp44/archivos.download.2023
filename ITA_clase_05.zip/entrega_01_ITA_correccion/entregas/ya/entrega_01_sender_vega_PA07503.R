#- entrega_01 (ITA, 2024-25)
#===============================================================================
#- recuerda que has de hacer la "entrega_01" usando un Rproject
#- contesta a las preguntas en este script.
#- no borres los enunciados de las preguntas
#- usa las IA's con moderación; mejor habla con tus compañeras/os, incluso con Google
#- Si tienes alguna duda, no dudes en preguntar
#- Intenta hacerlo todo, pero no me agobies (mucho) si no te sale todo, recuerda que estamos aprendiendo
#-------------------------------------------------------------------------------




#- TAREA 01: ------
#- En esta dirección hay unos datos: https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda
#- descarga ese fichero de datos y guárdalo en la subcarpeta "datos"

if (!dir.exists("datos")) {
  dir.create("datos")
}

url <- "https://github.com/perezp44/pjpv.datos.01/raw/master/data/pob_muni_1996_2020.rda"

destino <- file.path("datos", "pob_muni_1996_2020.rda")

download.file(url, destfile = destino, mode = "wb")

cat("Archivo descargado y guardado en la carpeta 'datos'.\n")



#- TAREA 02: ------
#- importa los datos que acabas de descargar al Global Env. 
#- Puedes hacerlo con el pkg "rio". Llama al objeto "df"
#- ¿En que formato están ahora los datos?

df <- rio::import("./datos/pob_muni_1996_2020.rda")



#- ¿En qué formato están los datos?
class(df)
#- El formato es: "data.frame"


#- TAREA 03: -------
#- Ahora tendrás que exportar 3 veces los datos que hay en "df" 3. Siempre en la carpeta "datos".
#- 3.a)  exporta los datos a formato . xlsx  (acuerdate de utilizar rutas relativas)

rio::export(df, "./datos/pob_muni_1996_2020.xlsx")

#- 3.b) Exporta los datos a formato .rds utilizando ruta relativa

rio::export(df, "./datos/pob_muni_1996_2020.rds")

#- 3.c) Expórtalos otra vez pero ahora en formato .csv


rio::export(df, "./datos/pob_muni_1996_2020.csv")

#- TAREA 04: -------
#- utiliza el pkg "eurostat" para descargar unos datos q medio te interesen.
#- Cuéntame (usando comentarios) que datos te has descargado y que variables tienes

# Instalar el paquete eurostat si no está instalado
if (!requireNamespace("eurostat", quietly = TRUE)) {
  install.packages("eurostat")
}

library(eurostat)

datos_desempleo <- get_eurostat("une_rt_a", time_format = "num")

head(datos_desempleo)

# Descripción: Este conjunto de datos contiene información sobre la tasa de desempleo en Europa. Las variables principales son:
# - geo: código del país (por ejemplo, "EU", "DE", "FR" para la UE, Alemania y Francia, respectivamente)
# - time: periodo de tiempo (añ y trimestre)
# - sex: sexo (masculino y femenino)
# - age: grupo de edad (generalmente "15-24", "25-54", "55-64" o "TOTAL")
# - values: tasa de desempleo en porcentaje

# 
freq  age    unit   sex   geo   TIME_PERIOD values
<chr> <chr>  <chr>  <chr> <chr>       <dbl>  <dbl>
  1 A     Y15-24 PC_ACT F     AT           2009   10.5
2 A     Y15-24 PC_ACT F     AT           2010    9.8
3 A     Y15-24 PC_ACT F     AT           2011    9.5
4 A     Y15-24 PC_ACT F     AT           2012    9.6
5 A     Y15-24 PC_ACT F     AT           2013   10.4
6 A     Y15-24 PC_ACT F     AT           2014   10.4

  
str(datos_desempleo)

tibble [34,116 × 7] (S3: tbl_df/tbl/data.frame)
$ freq       : chr [1:34116] "A" "A" "A" "A" ...
$ age        : chr [1:34116] "Y15-24" "Y15-24" "Y15-24" "Y15-24" ...
$ unit       : chr [1:34116] "PC_ACT" "PC_ACT" "PC_ACT" "PC_ACT" ...
$ sex        : chr [1:34116] "F" "F" "F" "F" ...
$ geo        : chr [1:34116] "AT" "AT" "AT" "AT" ...
$ TIME_PERIOD: num [1:34116] 2009 2010 2011 2012 2013 ...
$ values     : num [1:34116] 10.5 9.8 9.5 9.6 10.4 10.4 10.4 10.7 9.1 9.8 ...

PA07503

