#- Script para Slides-03: R base. https://perezp44.github.io/intro-ds-23-24-web/materiales/slides_03_R-base-01.html#1


# pp 5: Creación de objetos y asignación (<-) ----------------------------------
#- ¿Qué diferencias hay entre las siguientes 2 expresiones?
2 + 2
aa <- 2 + 2
 
#- una vez hemos creado una variable, podemos usarla para efectuar nuevos cálculos
aa + 1
 
#- podemos cambiar el valor de una variable
aa
aa <- 10
aa
 
#- ¿Qué hacen las siguientes lineas de código?
aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb

# pp 6: Global environment (primera referencia al) -----------------------------
aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb
 
ls()              #- muestra los objetos q hay en el  Global env.
rm(cc)            #- borra/elimina el objeto cc del Global env.
rm(list = ls())   #- borra todos los objetos del Global env.



# pp 8: Tipos de datos ---------------------------------------------------------
aa <- "La calle en la que vivo es"    #- texto (character)
bb <- 4L                              #- número entero
cc <- 4.3                             #- número decimal
dd <- TRUE                            #- logical
typeof(aa)
typeof(dd)



# pp 9: Operaciones con variables numéricas ------------------------------------

# operaciones aritméticas
2 + 2
5 * 6

# Operaciones de comparación
2 < 4    # MENOR que: esta expresión chequea si 2 es MENOR que cuatro. Como es cierto, nos devuelve un TRUE
2 > 4    # MAYOR que: esta expresión chequea si 2 es MAYOR que cuatro. Como es cierto, nos devuelve un TRUE
5 >= 7   # MAYOR o IGUAL que.
8 <= 8   # MENOR o IGUAL que.
5 == 4  # == IGUAL: == chequea si dos valores son iguales, como no son iguales devolverá FALSE
2 != 4   # NO IGUAL: como 2 no es igual a 4 nos devuelve TRUE
5 != 5   # NO IGUAL: como 5 es igual a 5, nos devuelve FALSE

# Fíjate
2 = 2    #- ¿qué ocurre? ¿xq se queja R?



# pp 10: Operaciones con texto -------------------------------------------------

aa <- "mi nombre es"
bb <- "pedro"
paste(aa, bb)
paste(aa, bb, sep = " ... ")
# Prueba tú mismo que hace la función paste0()

toupper(aa)
tolower(aa)
stringr::str_to_sentence(aa)   #- stringr es un pkg del tidyverse
nchar(bb)                      #- nchar() nos devuelve el número de caracteres de un string
substring(bb, 2, nchar(bb))    #- substring() extrae caracteres de un string  [🌶🌶]



# pp 11: Operaciones lógicas ---------------------------------------------------

# Los 3 principales operadores lógicos son: ( & ), ( |) y ( ! ). Son los operadores lógicos AND, OR y NOT

TRUE & TRUE    #- AND: para q devuelva TRUE hace falta que TODAS las condiciones sean ciertas
TRUE & FALSE
FALSE & FALSE
TRUE | TRUE   #- OR: devuelve TRUE si ALGUNA de las condiciones es cierta
TRUE | FALSE
FALSE | FALSE
!TRUE         #- NOT: devuelve el valor contrario
!FALSE

(4 > 3) & (3 < 2)  #- AND: como solo se cumple la primera condición, nos devuelve FALSE
(1==2) | (2 >3)   #- OR: Como no se cumple ninguna de las 2 condiciones nos devuelve FALSE
!(4 > 3)          #- NOT: 4 es mayor que 3 es TRUE, pero el ! delante de esa condición la niega y pasa a FALSE
!!(4 > 3)         #- si niegas dos veces, vuelves al principio: TRUE




# pp 16: Creación de vectores --------------------------------------------------

aa <- c(3, 22, 6)
aa
is.vector(aa)
typeof(aa)

# TAREA


#- pp 17: Coerción -------------------------------------------------------------

# coerción implicita
aa <- c(4, 6,  "Hola")  #- intentamos poner en aa elementos numéricos y character (¿?)
is.vector(aa)
typeof(aa)       #- ¿qué ha pasado?
aa               #- ¿qué ha pasado?

# coerción explicita
aa <- c(1:4)
aa
aa <- as.character(aa)
aa



#- pp 19: Vectores: 3 tipo de subseting ----------------------------------------

# 1. Seleccionar por posición
aa <- c(10:1)
aa[c(1:2)]        #- primer y segundo elemento del vector
aa[c(1, 2, 9, 10)]   #- dos primeros y 2 últimos
aa[c(1, 1, 10, 10)]  #- si repites el indice se repite el elemento del vector

# 2. Eliminar por posición
aa <- c(10:1)
aa[-2]
aa[- c(1, 2, 9:10)]

# 3. Subsetting lógico
aa <- 1:10
aa[aa >= 7]
aa[aa < 4]
aa[(aa >= 9) | (aa < 2)]
aa[(aa >= 9) & (aa < 2)]

#- pp 20 -----------------------------------------------------------------------

# Intenta entender bien el siguiente chunk. Es importante!!
aa <- 1:10
aa <= 4
aa[aa <= 4]

aa <- aa[aa <= 4]
aa


# Modificando elementos de un vector
aa <- c(1:10)
aa[4] <- 88             #- el cuarto elemento de aa tomará el valor 88
aa <- c(aa, 111, 112)   #- añadimos 2 elementos al vector aa


# Los vectores se pueden concatenar
aa <- c(1:5)
bb <- c(100:105)
cc <- c(aa, bb)


#- pp 21: Operaciones con vectores ---------------------------------------------
aa <- 1:10
bb <- 1:10
aa + bb
aa * bb


# Si quieres hacer álgebra matricial son otros operadores
aa  %*% bb

# Recycling
aa <- 1:10
aa + 1


#- pp 22: ----------------------------------------------------------------------

# Funciones vectorizadas
aa <- c(4, 9, 25)
sqrt(aa)

# Operaciones de comparación
aa <- 1:3
bb <- 3:1
aa == bb
aa >= bb
aa != bb

# En las operaciones de comparación también aplica el Recycling
aa <- 1:3
bb <- 2
aa == bb
aa >= bb
aa != bb


#- pp 24: Listas ---------------------------------------------------------------

# defino 3 vectores y una matriz
vec_numerico <- c(1:8)
vec_character <- c("Pedro", "Rebeca", "Susana")
vec_logic <- c(TRUE, FALSE, TRUE)
matriz <- matrix(1:6, nrow = 2, ncol = 3)

# creo una lista con cuatro elementos
my_list <- list(vec_numerico, vec_character, vec_logic, matriz)


#- pp 25: más cosas sobre las listas -------------------------------------------

my_list_2 <- list(primer_slot = c(44:47), segundo_slot = my_list)




#- pp 28: Creación de data frame's ---------------------------------------------

aa <- c(4, 8, 6, 3)
bb <- c("Juan", "Paz", "Adrian", "Marquitos")
cc <- c(FALSE, TRUE, TRUE, FALSE)
df <- data.frame(aa, bb, cc)
my_list_2
my_list


df <- data.frame(Nota = aa, Nombre = bb, Aprobado = cc)


#- pp 29: Subsetting en data frames --------------------------------------------

# subsetting como si fuera matriz (con [ )
df_s <- df[,1]        #- seleccionamos la primera columna. devuelve un vector !!!
df_s <- df[,c(2,3)]   #- seleccionamos la segunda y tercera columna. devuelve un df
df_s <- df[1, ]       #- seleccionamos primera fila de todas las variables. devuelve un df. ¿xq no devuelve un vector? Preguntad si no lo sabéis
df_s <- df[c(1,4), ]  #- seleccionamos primera y cuarta fila. devuelve un df
df_s <- df[2, 3]      #- seleccionamos segunda observación de la tercera variable. Devuelve un vector.



#- pp 30: data.frames: subsetting como si fuera una lista (con [, [[, $) -------

df_s <- df[3]        #- devuelve un df. Good!!
df_s <- df[c(1,2)]
#- también se puede hacer por nombre
df_s <- df["Name"]                #- devuelve un df
df_s <- df[c("Name", "Grade")]


df_s <- df[[2]]   #- Extraemos la segunda columna. Devuelve un vector, concretamente un factor. Ahhhh!!!!!


df_s <- df$Name   #- Extraemos la columna con nombre "Name". Devuelve un vector, concretamente un factor. Ahhhh!!!!!
df_s <- df$Grade  #- Extraemos la columna con nombre "Grade". Devuelve un vector numérico



#- pp 33: TAREA ----------------------------------------------------------------




#- pp 34, 35 y 36: seguimos con las funciones ----------------------------------

help(sqrt)


sqrt(9)
sqrt(9, 4)   #- no funciona ¿por qué? ¿cuantos argumentos tiene la f. sqrt()?
sqrt("9")    #- no funciona, ¿por qué? ¿Cómo, de que tipo, ha de ser el argumento?


#  Vamos a aprender a diferenciar el nombre y el valor del argumento de una f.
sqrt(9)
sqrt(x = 9)
x <- 25
sqrt(x)
sqrt(x = x)          #- !!!
sqrt(x = un_valor)   #- !!!
sqrt(nn = 9)         #- !!!


#- pp 37: TAREA ----------------------------------------------------------------